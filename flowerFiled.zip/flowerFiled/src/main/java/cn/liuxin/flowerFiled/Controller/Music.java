package cn.liuxin.flowerFiled.Controller;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Music {
    private static Music sound;
    private boolean openSound;
    private Player player;
    public Music() {
        File file=new File(".//msuic.mp3");
        InputStream inputSteam = null;
        try {
            inputSteam = new FileInputStream(file);
            player=new Player(inputSteam);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
        sound=this;
    }

    public Music(boolean openSound) {
        this.openSound = openSound;
    }

    public static Music getMusic() {
        if(sound==null)
            sound=new Music();
        return sound;
    }

    public boolean isOpenSound() {
        return openSound;
    }

    public void setOpenSound(boolean openSound) {
        this.openSound = openSound;
    }

    public void musicPlay()
    {
        try {
            player.play();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
    }
}
