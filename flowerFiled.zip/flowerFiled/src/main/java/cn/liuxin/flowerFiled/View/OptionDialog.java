package cn.liuxin.flowerFiled.View;

import javax.swing.*;

public class OptionDialog extends JDialog {
    private JPanel root;
    private JRadioButton simpleRb;
    private JRadioButton normalRb;
    private JRadioButton hardRb;
    private JRadioButton exprertRb;
    private JCheckBox safeFirstCb;
    private JCheckBox musicCB;
    private JButton SaveBtn;
    private JButton cancelBtn;
    private JRadioButton customRb;
    private JComboBox rowICB;
    private JComboBox colICB;
    private JComboBox bombICB;


}
