package cn.liuxin.flowerFiled;

import cn.liuxin.flowerFiled.Controller.Judge;
import cn.liuxin.flowerFiled.Controller.Music;
import cn.liuxin.flowerFiled.Controller.Util;
import cn.liuxin.flowerFiled.Model.Flower;
import cn.liuxin.flowerFiled.View.GamePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class Game {
    static Flower flower;
    static JFrame w =new JFrame();
    static GamePanel mPanel;
    public static void main(String[] args) {
        flower = new Flower();
        initMenu();
        flower.initFlowersMat();
        flower.printMat();

        new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    flower.getRedayToPlay().acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                mPanel = new GamePanel(Util.getUtil().getGridRow(), Util.getUtil().getGridCol(), Util.getUtil().getFlowersNum(),flower);
       /* long starTime=System.currentTimeMillis();

        long endTime=System.currentTimeMillis();
        System.out.println("===================");
        System.out.println("所用时间"+((endTime-starTime)%1000)+"秒");*/

                int[] panelSize = mPanel.returnSize();
                System.out.println("Size:"+w.getPreferredSize().width+","+w.getPreferredSize().height);
                w.setSize(panelSize[0],panelSize[1]+w.getPreferredSize().height);
                Container c =w.getContentPane();
                c.add(mPanel);
                w.setTitle("扫雷游戏");
                w.setResizable(false);
                w.setVisible(true);
                Judge.getJudge().setFrame(w);
                w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Music.getMusic().musicPlay();
            }
        }).start();
    }

    public static void initMenu()
    {
        JMenuBar menuBar=new JMenuBar();
        w.setJMenuBar(menuBar);

        JMenu gameMenu =createMenu("游戏","g");
        JMenuItem item;
        item=createMenu("新游戏","n");
        item.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int op=JOptionPane.showConfirmDialog(w,"确定要开始新游戏吗？");
                if(op==JOptionPane.YES_OPTION)
                {
                    Judge.getJudge().resetJudge();
                    gameRestart();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        gameMenu.add(item);
        gameMenu.add(createMenu("选项","s"));
        gameMenu.add(createMenu("退出","e"));
        JMenu aboutMenu = createMenu("关于","a");

        menuBar.add(gameMenu);
        menuBar.add(aboutMenu);

    }

    private static JMenu createMenu(String name, String mnemonic) {
        /*
         * 根据名称和快捷键创建menu并添加到menuBar
         */
        JMenu menu = new JMenu(name);
        if (mnemonic != null)
            menu.setMnemonic(mnemonic.toCharArray()[0]);
        return menu;
    }

    private static JMenuItem createMenuItem(String name, String mnemonic, Icon icon, KeyStroke keyStroke) {
        /*
         * 根据名称和快捷键创建menu并添加到menuBar
         */
        JMenuItem menuItem = new JMenuItem(name, icon);
        if (mnemonic != null)
            menuItem.setMnemonic(mnemonic.toCharArray()[0]);
        if (keyStroke != null)
            menuItem.setAccelerator(keyStroke);
        return menuItem;
    }

    public static void gameRestart()
    {
        flower.initFlowersMat();
        flower.printMat();
        mPanel.init();
        w.repaint();
    }
}
