package cn.liuxin.flowerFiled.Controller;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Sound {
    private static Sound sound;
    private boolean openSound;
    File clickFile;
    File flageFile;
    private Player player;
    public Sound() {
        clickFile=new File(".//click.mp3");
        flageFile=new File(".//flag.mp3");
        InputStream inputSteam = null;
        try {
            inputSteam = new FileInputStream(clickFile);
            player=new Player(inputSteam);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
        sound=this;
    }

    public Sound(boolean openSound) {
        this.openSound = openSound;
    }

    public static Sound getSound() {
        if(sound==null)
            sound=new Sound();
        return sound;
    }

    public boolean isOpenSound() {
        return openSound;
    }

    public void setOpenSound(boolean openSound) {
        this.openSound = openSound;
    }

    public void soundPlayClick()
    {
        try {
            InputStream inputStream = new FileInputStream(clickFile);
            player=new Player(inputStream);
        } catch (FileNotFoundException | JavaLayerException e) {
            e.printStackTrace();
        }

        try {
            player.play();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
    }

    public void soundPlayFlag()
    {
        try {
            InputStream inputStream = new FileInputStream(flageFile);
            player=new Player(inputStream);
        } catch (FileNotFoundException | JavaLayerException e) {
            e.printStackTrace();
        }
        try {
            player.play();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
    }
}
